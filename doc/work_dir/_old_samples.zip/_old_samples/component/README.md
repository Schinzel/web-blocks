# Sample
Start the class `io.schinzel.page_elements.samples.web.main`

Sample urls:
- Call landing page: http://127.0.0.1:5555/?user-id=ABC
- Invoke an API endpoint: http://127.0.0.1:5555/api/v1/user-information?user-id=123
- Call a page a in a subdirectory = http://127.0.0.1:5555/sub-dir/sub-dir-2
- Call a page-element in a page http://127.0.0.1:5555/page-api/user-account/update-name-pe/update-first-name/?user-id=123&first-name=Jack
- Call a page with interconnecting page-elements http://127.0.0.1:5555/user-account?user-id=123
